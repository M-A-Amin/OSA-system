// OSA System Complete JavaScript

// Global Variables
let currentUser = null;
let currentLanguage = 'ar';
let notifications = [];
let files = [];
let chats = [];
let exams = [];
let videoSessions = [];
let attendanceRecords = [];

// Language Translations
const translations = {
    ar: {
        // Navigation
        'home': 'الرئيسية',
        'login': 'تسجيل الدخول',
        'logout': 'تسجيل الخروج',
        'dashboard': 'لوحة التحكم',
        'profile': 'الملف الشخصي',
        'settings': 'الإعدادات',
        
        // User Types
        'student': 'طالب',
        'professor': 'أستاذ',
        'coordinator': 'منسق',
        'administrator': 'مدير النظام',
        
        // University Info
        'cairo_university': 'جامعة القاهرة',
        'faculty_name': 'كلية الدراسات العليا للبحوث الإحصائية',
        'online_studies_admin': 'إدارة الدراسات الإلكترونية',
        
        // Forms
        'name': 'الاسم',
        'email': 'البريد الإلكتروني',
        'password': 'كلمة المرور',
        'confirm_password': 'تأكيد كلمة المرور',
        'student_id': 'رقم الطالب',
        'national_id': 'الرقم القومي',
        'passport_id': 'رقم جواز السفر',
        'phone': 'رقم الهاتف',
        'university_email': 'البريد الجامعي',
        'university_code': 'الكود الجامعي',
        'subject_code': 'كود المادة',
        'subject_name': 'اسم المادة',
        'grade': 'الدرجة',
        'rating': 'التقدير',
        'exam_location': 'مكان الامتحان',
        'semester': 'الفصل الدراسي',
        'lecture_schedule': 'جدول المحاضرات',
        
        // Actions
        'create_account': 'إنشاء حساب',
        'edit': 'تعديل',
        'delete': 'حذف',
        'save': 'حفظ',
        'cancel': 'إلغاء',
        'submit': 'إرسال',
        'upload': 'رفع',
        'download': 'تحميل',
        'send': 'إرسال',
        'reply': 'رد',
        'forward': 'إعادة توجيه',
        'search': 'بحث',
        'filter': 'تصفية',
        'sort': 'ترتيب',
        'refresh': 'تحديث',
        'back': 'رجوع',
        'next': 'التالي',
        'previous': 'السابق',
        
        // Features
        'notifications': 'الإشعارات',
        'files': 'الملفات',
        'chat': 'الدردشة',
        'video_call': 'مكالمة فيديو',
        'exams': 'الاختبارات',
        'attendance': 'الحضور',
        'reports': 'التقارير',
        'schedule': 'الجدول',
        'subjects': 'المواد',
        'surveys': 'الاستطلاعات',
        'evaluations': 'التقييمات',
        
        // File Types
        'audio': 'صوت',
        'video': 'فيديو',
        'images': 'صور',
        'pdf': 'PDF',
        'excel': 'إكسل',
        'powerpoint': 'عرض تقديمي',
        
        // Messages
        'welcome': 'مرحباً',
        'success': 'تم بنجاح',
        'error': 'خطأ',
        'warning': 'تحذير',
        'info': 'معلومات',
        'confirm': 'تأكيد',
        'loading': 'جاري التحميل...',
        'no_data': 'لا توجد بيانات',
        'access_denied': 'غير مسموح بالوصول',
        'login_required': 'يجب تسجيل الدخول أولاً',
        'invalid_credentials': 'بيانات الدخول غير صحيحة',
        'password_changed': 'تم تغيير كلمة المرور بنجاح',
        'account_created': 'تم إنشاء الحساب بنجاح',
        'file_uploaded': 'تم رفع الملف بنجاح',
        'message_sent': 'تم إرسال الرسالة',
        'exam_submitted': 'تم إرسال الاختبار',
        'attendance_recorded': 'تم تسجيل الحضور',
        
        // Questions
        'no_account': 'ليس لديك حساب بعد؟',
        'forgot_password': 'نسيت كلمة المرور؟',
        'change_password': 'تغيير كلمة المرور',
        'first_login': 'تسجيل الدخول الأول',
        'confirm_delete': 'هل أنت متأكد من الحذف؟',
        'confirm_logout': 'هل تريد تسجيل الخروج؟',
        
        // Time
        'today': 'اليوم',
        'yesterday': 'أمس',
        'tomorrow': 'غداً',
        'this_week': 'هذا الأسبوع',
        'this_month': 'هذا الشهر',
        'date': 'التاريخ',
        'time': 'الوقت',
        'duration': 'المدة',
        
        // Status
        'active': 'نشط',
        'inactive': 'غير نشط',
        'online': 'متصل',
        'offline': 'غير متصل',
        'present': 'حاضر',
        'absent': 'غائب',
        'completed': 'مكتمل',
        'pending': 'في الانتظار',
        'approved': 'موافق عليه',
        'rejected': 'مرفوض'
    },
    en: {
        // Navigation
        'home': 'Home',
        'login': 'Login',
        'logout': 'Logout',
        'dashboard': 'Dashboard',
        'profile': 'Profile',
        'settings': 'Settings',
        
        // User Types
        'student': 'Student',
        'professor': 'Professor',
        'coordinator': 'Coordinator',
        'administrator': 'Administrator',
        
        // University Info
        'cairo_university': 'Cairo University',
        'faculty_name': 'Faculty of Graduate Studies for Statistical Research',
        'online_studies_admin': 'Online Studies Administration',
        
        // Forms
        'name': 'Name',
        'email': 'Email',
        'password': 'Password',
        'confirm_password': 'Confirm Password',
        'student_id': 'Student ID',
        'national_id': 'National ID',
        'passport_id': 'Passport ID',
        'phone': 'Phone',
        'university_email': 'University Email',
        'university_code': 'University Code',
        'subject_code': 'Subject Code',
        'subject_name': 'Subject Name',
        'grade': 'Grade',
        'rating': 'Rating',
        'exam_location': 'Exam Location',
        'semester': 'Semester',
        'lecture_schedule': 'Lecture Schedule',
        
        // Actions
        'create_account': 'Create Account',
        'edit': 'Edit',
        'delete': 'Delete',
        'save': 'Save',
        'cancel': 'Cancel',
        'submit': 'Submit',
        'upload': 'Upload',
        'download': 'Download',
        'send': 'Send',
        'reply': 'Reply',
        'forward': 'Forward',
        'search': 'Search',
        'filter': 'Filter',
        'sort': 'Sort',
        'refresh': 'Refresh',
        'back': 'Back',
        'next': 'Next',
        'previous': 'Previous',
        
        // Features
        'notifications': 'Notifications',
        'files': 'Files',
        'chat': 'Chat',
        'video_call': 'Video Call',
        'exams': 'Exams',
        'attendance': 'Attendance',
        'reports': 'Reports',
        'schedule': 'Schedule',
        'subjects': 'Subjects',
        'surveys': 'Surveys',
        'evaluations': 'Evaluations',
        
        // File Types
        'audio': 'Audio',
        'video': 'Video',
        'images': 'Images',
        'pdf': 'PDF',
        'excel': 'Excel',
        'powerpoint': 'PowerPoint',
        
        // Messages
        'welcome': 'Welcome',
        'success': 'Success',
        'error': 'Error',
        'warning': 'Warning',
        'info': 'Information',
        'confirm': 'Confirm',
        'loading': 'Loading...',
        'no_data': 'No Data',
        'access_denied': 'Access Denied',
        'login_required': 'Login Required',
        'invalid_credentials': 'Invalid Credentials',
        'password_changed': 'Password Changed Successfully',
        'account_created': 'Account Created Successfully',
        'file_uploaded': 'File Uploaded Successfully',
        'message_sent': 'Message Sent',
        'exam_submitted': 'Exam Submitted',
        'attendance_recorded': 'Attendance Recorded',
        
        // Questions
        'no_account': "Don't have an account yet?",
        'forgot_password': 'Forgot Password?',
        'change_password': 'Change Password',
        'first_login': 'First Login',
        'confirm_delete': 'Are you sure you want to delete?',
        'confirm_logout': 'Do you want to logout?',
        
        // Time
        'today': 'Today',
        'yesterday': 'Yesterday',
        'tomorrow': 'Tomorrow',
        'this_week': 'This Week',
        'this_month': 'This Month',
        'date': 'Date',
        'time': 'Time',
        'duration': 'Duration',
        
        // Status
        'active': 'Active',
        'inactive': 'Inactive',
        'online': 'Online',
        'offline': 'Offline',
        'present': 'Present',
        'absent': 'Absent',
        'completed': 'Completed',
        'pending': 'Pending',
        'approved': 'Approved',
        'rejected': 'Rejected'
    }
};

// Utility Functions
function t(key) {
    return translations[currentLanguage][key] || key;
}

function toggleLanguage() {
    currentLanguage = currentLanguage === 'ar' ? 'en' : 'ar';
    document.body.className = currentLanguage === 'en' ? 'en' : '';
    document.dir = currentLanguage === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('language', currentLanguage);
    updatePageContent();
}

function updatePageContent() {
    // Update all translatable elements
    document.querySelectorAll('[data-translate]').forEach(element => {
        const key = element.getAttribute('data-translate');
        element.textContent = t(key);
    });
    
    // Update placeholders
    document.querySelectorAll('[data-translate-placeholder]').forEach(element => {
        const key = element.getAttribute('data-translate-placeholder');
        element.placeholder = t(key);
    });
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    const container = document.getElementById('notifications-container') || document.body;
    container.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

function formatDate(date) {
    return new Date(date).toLocaleDateString(currentLanguage === 'ar' ? 'ar-EG' : 'en-US');
}

function formatTime(date) {
    return new Date(date).toLocaleTimeString(currentLanguage === 'ar' ? 'ar-EG' : 'en-US');
}

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Local Storage Functions
function saveToStorage(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

function loadFromStorage(key) {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
}

function removeFromStorage(key) {
    localStorage.removeItem(key);
}

// Authentication Functions
function initializeDefaultAdmin() {
    const users = loadFromStorage('users') || [];
    const adminExists = users.find(user => user.type === 'administrator');
    
    if (!adminExists) {
        const defaultAdmin = {
            id: 'admin-001',
            type: 'administrator',
            email: 'admin@admin.com',
            password: 'admin123',
            name: 'مدير النظام',
            nameEn: 'System Administrator',
            isFirstLogin: true,
            createdAt: new Date().toISOString(),
            lastLogin: null,
            isActive: true
        };
        
        users.push(defaultAdmin);
        saveToStorage('users', users);
    }
}

function login(credentials) {
    const users = loadFromStorage('users') || [];
    let user = null;
    
    // Check login based on user type
    if (credentials.type === 'student') {
        user = users.find(u => 
            u.type === 'student' && 
            u.studentId === credentials.identifier && 
            u.password === credentials.password
        );
    } else if (credentials.type === 'professor') {
        user = users.find(u => 
            u.type === 'professor' && 
            u.email === credentials.identifier && 
            u.universityCode === credentials.universityCode &&
            u.password === credentials.password
        );
    } else {
        user = users.find(u => 
            (u.type === credentials.type || credentials.type === 'administrator') && 
            u.email === credentials.identifier && 
            u.password === credentials.password
        );
    }
    
    if (user && user.isActive) {
        // Update last login
        user.lastLogin = new Date().toISOString();
        const userIndex = users.findIndex(u => u.id === user.id);
        users[userIndex] = user;
        saveToStorage('users', users);
        
        // Set current user
        currentUser = user;
        saveToStorage('currentUser', user);
        
        // Log login activity
        logActivity('login', user);
        
        return { success: true, user: user, isFirstLogin: user.isFirstLogin };
    }
    
    return { success: false, message: t('invalid_credentials') };
}

function logout() {
    if (currentUser) {
        logActivity('logout', currentUser);
    }
    
    currentUser = null;
    removeFromStorage('currentUser');
    window.location.href = 'index.html';
}

function changePassword(oldPassword, newPassword) {
    if (!currentUser) return { success: false, message: t('login_required') };
    
    if (currentUser.password !== oldPassword) {
        return { success: false, message: 'كلمة المرور الحالية غير صحيحة' };
    }
    
    const users = loadFromStorage('users') || [];
    const userIndex = users.findIndex(u => u.id === currentUser.id);
    
    if (userIndex !== -1) {
        users[userIndex].password = newPassword;
        users[userIndex].isFirstLogin = false;
        saveToStorage('users', users);
        
        currentUser.password = newPassword;
        currentUser.isFirstLogin = false;
        saveToStorage('currentUser', currentUser);
        
        return { success: true, message: t('password_changed') };
    }
    
    return { success: false, message: t('error') };
}

// User Management Functions
function createUser(userData) {
    const users = loadFromStorage('users') || [];
    
    // Check permissions
    if (!currentUser || 
        (userData.type === 'coordinator' && currentUser.type !== 'administrator') ||
        (userData.type === 'student' && currentUser.type !== 'coordinator') ||
        (userData.type === 'professor' && currentUser.type !== 'coordinator')) {
        return { success: false, message: t('access_denied') };
    }
    
    // Check for existing user
    const existingUser = users.find(u => 
        u.email === userData.email || 
        (userData.studentId && u.studentId === userData.studentId) ||
        (userData.universityCode && u.universityCode === userData.universityCode)
    );
    
    if (existingUser) {
        return { success: false, message: 'المستخدم موجود بالفعل' };
    }
    
    // Create new user
    const newUser = {
        id: generateId(),
        ...userData,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.id,
        isFirstLogin: true,
        isActive: true,
        lastLogin: null
    };
    
    users.push(newUser);
    saveToStorage('users', users);
    
    return { success: true, message: t('account_created'), user: newUser };
}

function updateUser(userId, userData) {
    const users = loadFromStorage('users') || [];
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
        return { success: false, message: 'المستخدم غير موجود' };
    }
    
    // Check permissions
    if (!currentUser || 
        (currentUser.type !== 'administrator' && currentUser.id !== userId)) {
        return { success: false, message: t('access_denied') };
    }
    
    users[userIndex] = { ...users[userIndex], ...userData };
    saveToStorage('users', users);
    
    if (currentUser.id === userId) {
        currentUser = users[userIndex];
        saveToStorage('currentUser', currentUser);
    }
    
    return { success: true, message: 'تم تحديث البيانات بنجاح' };
}

function deleteUser(userId) {
    const users = loadFromStorage('users') || [];
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
        return { success: false, message: 'المستخدم غير موجود' };
    }
    
    // Check permissions
    if (!currentUser || currentUser.type !== 'administrator') {
        return { success: false, message: t('access_denied') };
    }
    
    users.splice(userIndex, 1);
    saveToStorage('users', users);
    
    return { success: true, message: 'تم حذف المستخدم بنجاح' };
}

function getUsers(type = null) {
    const users = loadFromStorage('users') || [];
    return type ? users.filter(u => u.type === type) : users;
}

// Notification Functions
function sendNotification(notificationData) {
    const notifications = loadFromStorage('notifications') || [];
    
    const notification = {
        id: generateId(),
        ...notificationData,
        createdAt: new Date().toISOString(),
        isRead: false
    };
    
    notifications.push(notification);
    saveToStorage('notifications', notifications);
    
    return { success: true, message: t('message_sent') };
}

function getNotifications(userId) {
    const notifications = loadFromStorage('notifications') || [];
    return notifications.filter(n => 
        n.recipientId === userId || 
        n.recipientType === 'all' ||
        (currentUser && n.recipientType === currentUser.type)
    ).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function markNotificationAsRead(notificationId) {
    const notifications = loadFromStorage('notifications') || [];
    const notificationIndex = notifications.findIndex(n => n.id === notificationId);
    
    if (notificationIndex !== -1) {
        notifications[notificationIndex].isRead = true;
        saveToStorage('notifications', notifications);
    }
}

// File Management Functions
function uploadFile(fileData) {
    const files = loadFromStorage('files') || [];
    
    const file = {
        id: generateId(),
        ...fileData,
        uploadedAt: new Date().toISOString(),
        uploadedBy: currentUser.id,
        downloads: 0
    };
    
    files.push(file);
    saveToStorage('files', files);
    
    return { success: true, message: t('file_uploaded'), file: file };
}

function getFiles(category = null) {
    const files = loadFromStorage('files') || [];
    return category ? files.filter(f => f.category === category) : files;
}

function downloadFile(fileId) {
    const files = loadFromStorage('files') || [];
    const fileIndex = files.findIndex(f => f.id === fileId);
    
    if (fileIndex !== -1) {
        files[fileIndex].downloads++;
        saveToStorage('files', files);
        
        // Log download activity
        logActivity('file_download', currentUser, { fileId: fileId });
    }
}

// Chat Functions
function sendMessage(chatData) {
    const chats = loadFromStorage('chats') || [];
    
    const message = {
        id: generateId(),
        ...chatData,
        sentAt: new Date().toISOString(),
        isRead: false
    };
    
    chats.push(message);
    saveToStorage('chats', chats);
    
    return { success: true, message: t('message_sent') };
}

function getMessages(chatType, participantId = null) {
    const chats = loadFromStorage('chats') || [];
    
    if (chatType === 'private') {
        return chats.filter(c => 
            (c.senderId === currentUser.id && c.recipientId === participantId) ||
            (c.senderId === participantId && c.recipientId === currentUser.id)
        ).sort((a, b) => new Date(a.sentAt) - new Date(b.sentAt));
    } else {
        return chats.filter(c => c.chatType === 'group')
            .sort((a, b) => new Date(b.sentAt) - new Date(a.sentAt));
    }
}

// Exam Functions
function createExam(examData) {
    const exams = loadFromStorage('exams') || [];
    
    const exam = {
        id: generateId(),
        ...examData,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.id,
        submissions: []
    };
    
    exams.push(exam);
    saveToStorage('exams', exams);
    
    return { success: true, message: 'تم إنشاء الاختبار بنجاح', exam: exam };
}

function submitExam(examId, answers) {
    const exams = loadFromStorage('exams') || [];
    const examIndex = exams.findIndex(e => e.id === examId);
    
    if (examIndex === -1) {
        return { success: false, message: 'الاختبار غير موجود' };
    }
    
    const submission = {
        id: generateId(),
        studentId: currentUser.id,
        examId: examId,
        answers: answers,
        submittedAt: new Date().toISOString(),
        score: null,
        feedback: null
    };
    
    exams[examIndex].submissions.push(submission);
    saveToStorage('exams', exams);
    
    return { success: true, message: t('exam_submitted') };
}

function getExams(studentId = null) {
    const exams = loadFromStorage('exams') || [];
    
    if (currentUser.type === 'student') {
        return exams.filter(e => !e.submissions.find(s => s.studentId === currentUser.id));
    } else if (currentUser.type === 'professor') {
        return exams.filter(e => e.createdBy === currentUser.id);
    }
    
    return exams;
}

// Video Call Functions
function createVideoSession(sessionData) {
    const videoSessions = loadFromStorage('videoSessions') || [];
    
    const session = {
        id: generateId(),
        ...sessionData,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.id,
        participants: [],
        isActive: true
    };
    
    videoSessions.push(session);
    saveToStorage('videoSessions', videoSessions);
    
    return { success: true, message: 'تم إنشاء جلسة الفيديو بنجاح', session: session };
}

function joinVideoSession(sessionId) {
    const videoSessions = loadFromStorage('videoSessions') || [];
    const sessionIndex = videoSessions.findIndex(s => s.id === sessionId);
    
    if (sessionIndex !== -1) {
        const participant = {
            userId: currentUser.id,
            joinedAt: new Date().toISOString(),
            leftAt: null
        };
        
        videoSessions[sessionIndex].participants.push(participant);
        saveToStorage('videoSessions', videoSessions);
        
        // Record attendance
        recordAttendance(sessionId);
        
        return { success: true, session: videoSessions[sessionIndex] };
    }
    
    return { success: false, message: 'الجلسة غير موجودة' };
}

// Attendance Functions
function recordAttendance(sessionId) {
    const attendanceRecords = loadFromStorage('attendanceRecords') || [];
    
    const record = {
        id: generateId(),
        studentId: currentUser.id,
        sessionId: sessionId,
        recordedAt: new Date().toISOString(),
        status: 'present'
    };
    
    attendanceRecords.push(record);
    saveToStorage('attendanceRecords', attendanceRecords);
    
    return { success: true, message: t('attendance_recorded') };
}

function getAttendanceRecords(studentId = null, sessionId = null) {
    const attendanceRecords = loadFromStorage('attendanceRecords') || [];
    
    let records = attendanceRecords;
    
    if (studentId) {
        records = records.filter(r => r.studentId === studentId);
    }
    
    if (sessionId) {
        records = records.filter(r => r.sessionId === sessionId);
    }
    
    return records;
}

// Activity Logging
function logActivity(action, user, details = {}) {
    const activities = loadFromStorage('activities') || [];
    
    const activity = {
        id: generateId(),
        userId: user.id,
        userType: user.type,
        action: action,
        details: details,
        timestamp: new Date().toISOString(),
        ipAddress: 'Unknown', // In a real app, this would be captured
        userAgent: navigator.userAgent,
        country: 'Unknown' // In a real app, this would be detected
    };
    
    activities.push(activity);
    saveToStorage('activities', activities);
}

function getActivityReports() {
    const activities = loadFromStorage('activities') || [];
    return activities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

// Schedule Functions
function createSchedule(scheduleData) {
    const schedules = loadFromStorage('schedules') || [];
    
    const schedule = {
        id: generateId(),
        ...scheduleData,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.id
    };
    
    schedules.push(schedule);
    saveToStorage('schedules', schedules);
    
    return { success: true, message: 'تم إنشاء الجدول بنجاح' };
}

function getSchedules() {
    const schedules = loadFromStorage('schedules') || [];
    return schedules;
}

// Survey Functions
function createSurvey(surveyData) {
    const surveys = loadFromStorage('surveys') || [];
    
    const survey = {
        id: generateId(),
        ...surveyData,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.id,
        responses: []
    };
    
    surveys.push(survey);
    saveToStorage('surveys', surveys);
    
    return { success: true, message: 'تم إنشاء الاستطلاع بنجاح' };
}

function submitSurveyResponse(surveyId, responses) {
    const surveys = loadFromStorage('surveys') || [];
    const surveyIndex = surveys.findIndex(s => s.id === surveyId);
    
    if (surveyIndex !== -1) {
        const response = {
            id: generateId(),
            studentId: currentUser.id,
            surveyId: surveyId,
            responses: responses,
            submittedAt: new Date().toISOString()
        };
        
        surveys[surveyIndex].responses.push(response);
        saveToStorage('surveys', surveys);
        
        return { success: true, message: 'تم إرسال الاستطلاع بنجاح' };
    }
    
    return { success: false, message: 'الاستطلاع غير موجود' };
}

function getSurveys() {
    const surveys = loadFromStorage('surveys') || [];
    
    if (currentUser.type === 'student') {
        return surveys.filter(s => !s.responses.find(r => r.studentId === currentUser.id));
    } else if (currentUser.type === 'coordinator') {
        return surveys.filter(s => s.createdBy === currentUser.id);
    }
    
    return surveys;
}

// Modal Functions
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

function hideAllModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
    });
}

// Form Validation
function validateForm(formData, rules) {
    const errors = [];
    
    for (const field in rules) {
        const value = formData[field];
        const rule = rules[field];
        
        if (rule.required && (!value || value.trim() === '')) {
            errors.push(`${field} مطلوب`);
        }
        
        if (rule.minLength && value && value.length < rule.minLength) {
            errors.push(`${field} يجب أن يكون ${rule.minLength} أحرف على الأقل`);
        }
        
        if (rule.email && value && !isValidEmail(value)) {
            errors.push(`${field} غير صحيح`);
        }
        
        if (rule.match && value !== formData[rule.match]) {
            errors.push(`${field} غير متطابق`);
        }
    }
    
    return errors;
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// File Upload Handling
function handleFileUpload(file, category) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            const fileData = {
                name: file.name,
                size: file.size,
                type: file.type,
                category: category,
                content: e.target.result
            };
            
            const result = uploadFile(fileData);
            if (result.success) {
                resolve(result);
            } else {
                reject(result);
            }
        };
        
        reader.onerror = function() {
            reject({ success: false, message: 'خطأ في قراءة الملف' });
        };
        
        reader.readAsDataURL(file);
    });
}

// Initialize Application
function initializeApp() {
    // Load saved language
    const savedLanguage = localStorage.getItem('language');
    if (savedLanguage) {
        currentLanguage = savedLanguage;
        document.body.className = currentLanguage === 'en' ? 'en' : '';
        document.dir = currentLanguage === 'ar' ? 'rtl' : 'ltr';
    }
    
    // Load current user
    const savedUser = loadFromStorage('currentUser');
    if (savedUser) {
        currentUser = savedUser;
    }
    
    // Initialize default admin
    initializeDefaultAdmin();
    
    // Update page content
    updatePageContent();
    
    // Set up event listeners
    setupEventListeners();
}

function setupEventListeners() {
    // Language toggle
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('language-toggle')) {
            toggleLanguage();
        }
    });
    
    // Modal close
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-close') || e.target.classList.contains('modal')) {
            hideAllModals();
        }
    });
    
    // File upload drag and drop
    document.addEventListener('dragover', function(e) {
        e.preventDefault();
        if (e.target.classList.contains('file-upload-area')) {
            e.target.classList.add('dragover');
        }
    });
    
    document.addEventListener('dragleave', function(e) {
        if (e.target.classList.contains('file-upload-area')) {
            e.target.classList.remove('dragover');
        }
    });
    
    document.addEventListener('drop', function(e) {
        e.preventDefault();
        if (e.target.classList.contains('file-upload-area')) {
            e.target.classList.remove('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                const category = e.target.getAttribute('data-category') || 'general';
                handleFileUpload(files[0], category);
            }
        }
    });
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initializeApp);

// Export functions for use in HTML pages
window.OSA = {
    // Authentication
    login,
    logout,
    changePassword,
    
    // User Management
    createUser,
    updateUser,
    deleteUser,
    getUsers,
    
    // Notifications
    sendNotification,
    getNotifications,
    markNotificationAsRead,
    
    // Files
    uploadFile,
    getFiles,
    downloadFile,
    handleFileUpload,
    
    // Chat
    sendMessage,
    getMessages,
    
    // Exams
    createExam,
    submitExam,
    getExams,
    
    // Video Calls
    createVideoSession,
    joinVideoSession,
    
    // Attendance
    recordAttendance,
    getAttendanceRecords,
    
    // Schedule
    createSchedule,
    getSchedules,
    
    // Surveys
    createSurvey,
    submitSurveyResponse,
    getSurveys,
    
    // Reports
    getActivityReports,
    
    // Utilities
    showModal,
    hideModal,
    showNotification,
    validateForm,
    t,
    toggleLanguage,
    formatDate,
    formatTime,
    
    // Current state
    getCurrentUser: () => currentUser,
    getCurrentLanguage: () => currentLanguage
};



// IP and User Info Functions
async function getUserInfo() {
    const userInfo = {
        ip: 'Unknown',
        browser: navigator.userAgent,
        country: 'Unknown',
        loginTime: new Date().toISOString(),
        sessionId: generateSessionId()
    };
    
    try {
        // Try to get IP from multiple sources
        const response = await fetch('https://api.ipify.org?format=json');
        const data = await response.json();
        userInfo.ip = data.ip;
        
        // Try to get country info
        const geoResponse = await fetch(`https://ipapi.co/${data.ip}/json/`);
        const geoData = await geoResponse.json();
        userInfo.country = geoData.country_name || 'Unknown';
    } catch (error) {
        console.log('Could not fetch IP info:', error);
        // Fallback to local IP detection
        try {
            const rtc = new RTCPeerConnection({iceServers:[]});
            rtc.createDataChannel('');
            rtc.createOffer().then(offer => rtc.setLocalDescription(offer));
            rtc.onicecandidate = function(ice) {
                if (ice && ice.candidate && ice.candidate.candidate) {
                    const ip = /([0-9]{1,3}(\.[0-9]{1,3}){3})/.exec(ice.candidate.candidate)[1];
                    userInfo.ip = ip;
                    rtc.onicecandidate = null;
                }
            };
        } catch (e) {
            console.log('Local IP detection failed:', e);
        }
    }
    
    return userInfo;
}

function generateSessionId() {
    return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
}

// Login Report Functions
function saveLoginReport(userInfo, user) {
    const loginReports = JSON.parse(localStorage.getItem('loginReports') || '[]');
    const report = {
        id: generateId(),
        userId: user.id,
        username: user.email || user.studentId || user.universityCode,
        name: user.name,
        userType: user.type,
        email: user.email,
        ip: userInfo.ip,
        browser: userInfo.browser,
        country: userInfo.country,
        loginTime: userInfo.loginTime,
        sessionId: userInfo.sessionId,
        logoutTime: null,
        sessionDuration: null
    };
    
    loginReports.push(report);
    localStorage.setItem('loginReports', JSON.stringify(loginReports));
}

function updateLogoutReport(sessionId) {
    const loginReports = JSON.parse(localStorage.getItem('loginReports') || '[]');
    const reportIndex = loginReports.findIndex(report => report.sessionId === sessionId);
    
    if (reportIndex !== -1) {
        const logoutTime = new Date().toISOString();
        const loginTime = new Date(loginReports[reportIndex].loginTime);
        const duration = Math.round((new Date(logoutTime) - loginTime) / 1000 / 60); // minutes
        
        loginReports[reportIndex].logoutTime = logoutTime;
        loginReports[reportIndex].sessionDuration = duration;
        
        localStorage.setItem('loginReports', JSON.stringify(loginReports));
    }
}

// Notification System
function createNotification(title, message, type = 'info', targetUsers = []) {
    const notification = {
        id: generateId(),
        title: title,
        message: message,
        type: type, // info, success, warning, error
        targetUsers: targetUsers, // empty array means all users
        createdBy: currentUser.id,
        createdAt: new Date().toISOString(),
        readBy: []
    };
    
    const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    notifications.push(notification);
    localStorage.setItem('notifications', JSON.stringify(notifications));
    
    // Show notification popup
    showNotificationPopup(notification);
    
    return notification;
}

function showNotificationPopup(notification) {
    const popup = document.createElement('div');
    popup.className = `notification-popup ${notification.type}`;
    popup.innerHTML = `
        <div class="d-flex justify-content-between align-items-start">
            <div>
                <h6 class="mb-1">${notification.title}</h6>
                <p class="mb-0 small">${notification.message}</p>
            </div>
            <button type="button" class="btn-close btn-close-sm" onclick="this.parentElement.parentElement.remove()"></button>
        </div>
    `;
    
    document.body.appendChild(popup);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (popup.parentElement) {
            popup.remove();
        }
    }, 5000);
}

function getNotificationsForUser(userId) {
    const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    return notifications.filter(notification => 
        notification.targetUsers.length === 0 || 
        notification.targetUsers.includes(userId)
    );
}

function markNotificationAsRead(notificationId, userId) {
    const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    const notification = notifications.find(n => n.id === notificationId);
    
    if (notification && !notification.readBy.includes(userId)) {
        notification.readBy.push(userId);
        localStorage.setItem('notifications', JSON.stringify(notifications));
    }
}

// Video Call System
class VideoCallManager {
    constructor() {
        this.localStream = null;
        this.remoteStreams = new Map();
        this.peerConnections = new Map();
        this.isCallActive = false;
        this.isMuted = false;
        this.isVideoOff = false;
        this.isScreenSharing = false;
        this.chatMessages = [];
        this.participants = new Map();
    }
    
    async initializeCall(meetingId, isHost = false) {
        try {
            this.meetingId = meetingId;
            this.isHost = isHost;
            
            // Get user media
            this.localStream = await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: true
            });
            
            // Create video call UI
            this.createVideoCallUI();
            
            // Add local video
            this.addLocalVideo();
            
            this.isCallActive = true;
            
            // Save meeting info
            this.saveMeetingInfo();
            
            return true;
        } catch (error) {
            console.error('Error initializing call:', error);
            alert('خطأ في بدء المكالمة: ' + error.message);
            return false;
        }
    }
    
    createVideoCallUI() {
        const videoCallContainer = document.createElement('div');
        videoCallContainer.className = 'video-call-container';
        videoCallContainer.id = 'video-call-container';
        videoCallContainer.innerHTML = `
            <div class="meeting-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">اجتماع: ${this.meetingId}</h5>
                    <div class="meeting-info">
                        <span class="badge bg-success me-2">متصل</span>
                        <span class="participants-count">المشاركون: 1</span>
                    </div>
                </div>
            </div>
            
            <div class="participant-grid" id="participant-grid">
                <!-- Participants will be added here -->
            </div>
            
            <div class="video-controls">
                <button class="control-btn mute" id="mute-btn" onclick="videoCallManager.toggleMute()">
                    <i class="fas fa-microphone"></i>
                </button>
                <button class="control-btn video" id="video-btn" onclick="videoCallManager.toggleVideo()">
                    <i class="fas fa-video"></i>
                </button>
                <button class="control-btn screen" id="screen-btn" onclick="videoCallManager.toggleScreenShare()">
                    <i class="fas fa-desktop"></i>
                </button>
                <button class="control-btn chat" id="chat-btn" onclick="videoCallManager.toggleChat()">
                    <i class="fas fa-comment"></i>
                </button>
                <button class="control-btn end" onclick="videoCallManager.endCall()">
                    <i class="fas fa-phone-slash"></i>
                </button>
            </div>
            
            <div class="chat-sidebar" id="chat-sidebar">
                <div class="chat-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <span>الدردشة</span>
                        <button class="btn btn-sm btn-outline-light" onclick="videoCallManager.toggleChat()">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="chat-messages" id="chat-messages">
                    <!-- Chat messages will appear here -->
                </div>
                <div class="chat-input">
                    <div class="input-group">
                        <input type="text" class="form-control" id="chat-input" placeholder="اكتب رسالة..." onkeypress="if(event.key==='Enter') videoCallManager.sendChatMessage()">
                        <button class="btn btn-primary" onclick="videoCallManager.sendChatMessage()">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(videoCallContainer);
        videoCallContainer.style.display = 'block';
    }
    
    addLocalVideo() {
        const participantGrid = document.getElementById('participant-grid');
        const localVideoCard = document.createElement('div');
        localVideoCard.className = 'participant-card';
        localVideoCard.id = 'local-participant';
        localVideoCard.innerHTML = `
            <div class="participant-video">
                <video id="local-video" autoplay muted playsinline></video>
            </div>
            <div class="participant-name">${currentUser.name} (أنت)</div>
            <div class="participant-status">متصل</div>
        `;
        
        participantGrid.appendChild(localVideoCard);
        
        const localVideo = document.getElementById('local-video');
        localVideo.srcObject = this.localStream;
    }
    
    toggleMute() {
        this.isMuted = !this.isMuted;
        const audioTracks = this.localStream.getAudioTracks();
        audioTracks.forEach(track => track.enabled = !this.isMuted);
        
        const muteBtn = document.getElementById('mute-btn');
        muteBtn.innerHTML = this.isMuted ? 
            '<i class="fas fa-microphone-slash"></i>' : 
            '<i class="fas fa-microphone"></i>';
        muteBtn.style.background = this.isMuted ? '#dc3545' : '#28a745';
    }
    
    toggleVideo() {
        this.isVideoOff = !this.isVideoOff;
        const videoTracks = this.localStream.getVideoTracks();
        videoTracks.forEach(track => track.enabled = !this.isVideoOff);
        
        const videoBtn = document.getElementById('video-btn');
        videoBtn.innerHTML = this.isVideoOff ? 
            '<i class="fas fa-video-slash"></i>' : 
            '<i class="fas fa-video"></i>';
        videoBtn.style.background = this.isVideoOff ? '#dc3545' : '#007bff';
    }
    
    async toggleScreenShare() {
        try {
            if (!this.isScreenSharing) {
                // Start screen sharing
                const screenStream = await navigator.mediaDevices.getDisplayMedia({
                    video: true,
                    audio: true
                });
                
                // Replace video track
                const videoTrack = screenStream.getVideoTracks()[0];
                const sender = this.peerConnections.values().next().value?.getSenders().find(s => 
                    s.track && s.track.kind === 'video'
                );
                
                if (sender) {
                    await sender.replaceTrack(videoTrack);
                }
                
                // Update local video
                const localVideo = document.getElementById('local-video');
                localVideo.srcObject = screenStream;
                
                this.isScreenSharing = true;
                
                // Handle screen share end
                videoTrack.onended = () => {
                    this.stopScreenShare();
                };
                
                const screenBtn = document.getElementById('screen-btn');
                screenBtn.style.background = '#ffc107';
                screenBtn.innerHTML = '<i class="fas fa-stop"></i>';
                
            } else {
                this.stopScreenShare();
            }
        } catch (error) {
            console.error('Error toggling screen share:', error);
            alert('خطأ في مشاركة الشاشة: ' + error.message);
        }
    }
    
    async stopScreenShare() {
        try {
            // Get camera stream back
            const cameraStream = await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: true
            });
            
            // Replace video track
            const videoTrack = cameraStream.getVideoTracks()[0];
            const sender = this.peerConnections.values().next().value?.getSenders().find(s => 
                s.track && s.track.kind === 'video'
            );
            
            if (sender) {
                await sender.replaceTrack(videoTrack);
            }
            
            // Update local video
            const localVideo = document.getElementById('local-video');
            localVideo.srcObject = cameraStream;
            
            this.localStream = cameraStream;
            this.isScreenSharing = false;
            
            const screenBtn = document.getElementById('screen-btn');
            screenBtn.style.background = '#28a745';
            screenBtn.innerHTML = '<i class="fas fa-desktop"></i>';
            
        } catch (error) {
            console.error('Error stopping screen share:', error);
        }
    }
    
    toggleChat() {
        const chatSidebar = document.getElementById('chat-sidebar');
        chatSidebar.classList.toggle('open');
    }
    
    sendChatMessage() {
        const chatInput = document.getElementById('chat-input');
        const message = chatInput.value.trim();
        
        if (message) {
            const chatMessage = {
                id: generateId(),
                sender: currentUser.name,
                message: message,
                timestamp: new Date().toISOString()
            };
            
            this.chatMessages.push(chatMessage);
            this.displayChatMessage(chatMessage, true);
            
            chatInput.value = '';
            
            // In a real implementation, send to other participants
            this.broadcastChatMessage(chatMessage);
        }
    }
    
    displayChatMessage(chatMessage, isOwn = false) {
        const chatMessages = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isOwn ? 'own' : 'other'}`;
        
        const time = new Date(chatMessage.timestamp).toLocaleTimeString('ar-EG', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        messageDiv.innerHTML = `
            <div class="message-sender">${chatMessage.sender}</div>
            <div class="message-content">${chatMessage.message}</div>
            <div class="message-time">${time}</div>
        `;
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    broadcastChatMessage(chatMessage) {
        // In a real implementation, this would send the message to all participants
        // For demo purposes, we'll simulate receiving our own message from others
        setTimeout(() => {
            if (Math.random() > 0.7) { // 30% chance of getting a response
                const responses = [
                    'شكراً لك',
                    'موافق',
                    'فهمت',
                    'ممتاز',
                    'سؤال جيد'
                ];
                const response = {
                    id: generateId(),
                    sender: 'مشارك آخر',
                    message: responses[Math.floor(Math.random() * responses.length)],
                    timestamp: new Date().toISOString()
                };
                this.displayChatMessage(response, false);
            }
        }, 2000 + Math.random() * 3000);
    }
    
    saveMeetingInfo() {
        const meetings = JSON.parse(localStorage.getItem('meetings') || '[]');
        const meeting = {
            id: this.meetingId,
            hostId: currentUser.id,
            hostName: currentUser.name,
            startTime: new Date().toISOString(),
            endTime: null,
            participants: [currentUser.id],
            chatMessages: [],
            isActive: true
        };
        
        meetings.push(meeting);
        localStorage.setItem('meetings', JSON.stringify(meetings));
    }
    
    endCall() {
        if (confirm('هل أنت متأكد من إنهاء المكالمة؟')) {
            // Stop all tracks
            if (this.localStream) {
                this.localStream.getTracks().forEach(track => track.stop());
            }
            
            // Close peer connections
            this.peerConnections.forEach(pc => pc.close());
            this.peerConnections.clear();
            
            // Update meeting info
            this.updateMeetingEndTime();
            
            // Remove video call UI
            const videoCallContainer = document.getElementById('video-call-container');
            if (videoCallContainer) {
                videoCallContainer.remove();
            }
            
            this.isCallActive = false;
            
            // Show end call message
            showNotificationPopup({
                title: 'انتهت المكالمة',
                message: 'تم إنهاء المكالمة بنجاح',
                type: 'info'
            });
        }
    }
    
    updateMeetingEndTime() {
        const meetings = JSON.parse(localStorage.getItem('meetings') || '[]');
        const meeting = meetings.find(m => m.id === this.meetingId);
        
        if (meeting) {
            meeting.endTime = new Date().toISOString();
            meeting.isActive = false;
            meeting.chatMessages = this.chatMessages;
            localStorage.setItem('meetings', JSON.stringify(meetings));
        }
    }
}

// Initialize video call manager
const videoCallManager = new VideoCallManager();

// Meeting Functions
function createMeeting(title, description, participants = []) {
    const meetingId = 'meeting_' + generateId();
    const meeting = {
        id: meetingId,
        title: title,
        description: description,
        hostId: currentUser.id,
        hostName: currentUser.name,
        participants: participants,
        createdAt: new Date().toISOString(),
        scheduledTime: null,
        isActive: false,
        meetingUrl: `meeting.html?id=${meetingId}`
    };
    
    const meetings = JSON.parse(localStorage.getItem('meetings') || '[]');
    meetings.push(meeting);
    localStorage.setItem('meetings', JSON.stringify(meetings));
    
    // Send notification to participants
    if (participants.length > 0) {
        createNotification(
            'دعوة لاجتماع جديد',
            `تم دعوتك للمشاركة في اجتماع: ${title}`,
            'info',
            participants
        );
    }
    
    return meeting;
}

function joinMeeting(meetingId) {
    const meetings = JSON.parse(localStorage.getItem('meetings') || '[]');
    const meeting = meetings.find(m => m.id === meetingId);
    
    if (!meeting) {
        alert('الاجتماع غير موجود');
        return false;
    }
    
    // Check if user is invited
    if (meeting.participants.length > 0 && 
        !meeting.participants.includes(currentUser.id) && 
        meeting.hostId !== currentUser.id) {
        alert('غير مسموح لك بالانضمام لهذا الاجتماع');
        return false;
    }
    
    // Start video call
    const isHost = meeting.hostId === currentUser.id;
    return videoCallManager.initializeCall(meetingId, isHost);
}

// Professor Notification Functions
function sendNotificationToProfessor(title, message, targetStudents = []) {
    if (currentUser.type !== 'professor') {
        alert('هذه الميزة متاحة للأساتذة فقط');
        return;
    }
    
    return createNotification(title, message, 'info', targetStudents);
}

function sendNotificationToAllStudents(title, message) {
    if (currentUser.type !== 'professor') {
        alert('هذه الميزة متاحة للأساتذة فقط');
        return;
    }
    
    // Get all students
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const students = users.filter(user => user.type === 'student');
    const studentIds = students.map(student => student.id);
    
    return createNotification(title, message, 'info', studentIds);
}

// Enhanced Login Function with IP Tracking
async function enhancedLogin(email, password, userType) {
    try {
        // Get user info including IP
        const userInfo = await getUserInfo();
        
        // Perform login
        const result = performLogin(email, password, userType);
        
        if (result.success) {
            // Save login report
            saveLoginReport(userInfo, result.user);
            
            // Store session info for logout tracking
            sessionStorage.setItem('currentSessionId', userInfo.sessionId);
            
            return result;
        }
        
        return result;
    } catch (error) {
        console.error('Enhanced login error:', error);
        return { success: false, message: 'خطأ في تسجيل الدخول' };
    }
}

// Enhanced Logout Function
function enhancedLogout() {
    const sessionId = sessionStorage.getItem('currentSessionId');
    if (sessionId) {
        updateLogoutReport(sessionId);
        sessionStorage.removeItem('currentSessionId');
    }
    
    // Clear current user
    currentUser = null;
    localStorage.removeItem('currentUser');
    
    // Redirect to home page
    window.location.href = 'index.html';
}

// Update the global logout function
function logout() {
    enhancedLogout();
}

// Initialize enhanced features
document.addEventListener('DOMContentLoaded', function() {
    // Load notifications for current user
    if (currentUser) {
        loadUserNotifications();
    }
    
    // Set up periodic notification check
    setInterval(checkForNewNotifications, 30000); // Check every 30 seconds
});

function loadUserNotifications() {
    if (!currentUser) return;
    
    const notifications = getNotificationsForUser(currentUser.id);
    const unreadNotifications = notifications.filter(n => !n.readBy.includes(currentUser.id));
    
    // Update notification badge
    updateNotificationBadge(unreadNotifications.length);
    
    // Display recent notifications
    displayRecentNotifications(unreadNotifications.slice(0, 5));
}

function updateNotificationBadge(count) {
    const badge = document.getElementById('notification-badge');
    if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'inline' : 'none';
    }
}

function displayRecentNotifications(notifications) {
    const container = document.getElementById('recent-notifications');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (notifications.length === 0) {
        container.innerHTML = '<p class="text-muted">لا توجد إشعارات جديدة</p>';
        return;
    }
    
    notifications.forEach(notification => {
        const notificationElement = document.createElement('div');
        notificationElement.className = 'alert alert-info alert-dismissible';
        notificationElement.innerHTML = `
            <h6>${notification.title}</h6>
            <p class="mb-1">${notification.message}</p>
            <small class="text-muted">${formatDate(notification.createdAt)}</small>
            <button type="button" class="btn-close" onclick="markNotificationAsRead('${notification.id}', '${currentUser.id}'); this.parentElement.remove();"></button>
        `;
        container.appendChild(notificationElement);
    });
}

function checkForNewNotifications() {
    if (currentUser) {
        loadUserNotifications();
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-EG') + ' ' + date.toLocaleTimeString('ar-EG', {
        hour: '2-digit',
        minute: '2-digit'
    });
}



// Assignment Management Functions
function showCreateAssignmentModal() {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إنشاء مهمة جديدة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="assignment-form">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">عنوان المهمة</label>
                                    <input type="text" class="form-control" id="assignment-title" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">المادة</label>
                                    <select class="form-select" id="assignment-subject" required>
                                        <option value="">اختر المادة</option>
                                        <option value="STAT301">الإحصاء المتقدم</option>
                                        <option value="DATA401">تحليل البيانات</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">وصف المهمة</label>
                            <textarea class="form-control" id="assignment-description" rows="4" required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">تاريخ التسليم</label>
                                    <input type="datetime-local" class="form-control" id="assignment-deadline" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">الدرجة الكاملة</label>
                                    <input type="number" class="form-control" id="assignment-total-grade" min="1" max="100" value="10" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">نوع التسليم</label>
                            <select class="form-select" id="assignment-submission-type">
                                <option value="file">رفع ملف</option>
                                <option value="text">نص مكتوب</option>
                                <option value="both">كلاهما</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ملف مرفق (اختياري)</label>
                            <input type="file" class="form-control" id="assignment-attachment" accept="*/*">
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="assignment-notify" checked>
                                <label class="form-check-label" for="assignment-notify">
                                    إرسال إشعار للطلاب عند إنشاء المهمة
                                </label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="button" class="btn btn-primary" onclick="createAssignment()">إنشاء المهمة</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
}

function createAssignment() {
    const title = document.getElementById('assignment-title').value;
    const subject = document.getElementById('assignment-subject').value;
    const description = document.getElementById('assignment-description').value;
    const deadline = document.getElementById('assignment-deadline').value;
    const totalGrade = document.getElementById('assignment-total-grade').value;
    const submissionType = document.getElementById('assignment-submission-type').value;
    const notify = document.getElementById('assignment-notify').checked;

    if (!title || !subject || !description || !deadline) {
        showAlert('يرجى ملء جميع الحقول المطلوبة', 'error');
        return;
    }

    const assignment = {
        id: 'assign_' + Date.now(),
        title: title,
        subject: subject,
        description: description,
        deadline: deadline,
        totalGrade: parseInt(totalGrade),
        submissionType: submissionType,
        createdAt: new Date().toISOString(),
        createdBy: getCurrentUser().id,
        submissions: [],
        status: 'active'
    };

    // Save assignment
    let assignments = JSON.parse(localStorage.getItem('assignments') || '[]');
    assignments.push(assignment);
    localStorage.setItem('assignments', JSON.stringify(assignments));

    // Send notification if requested
    if (notify) {
        sendNotification({
            title: 'مهمة جديدة: ' + title,
            message: 'تم إنشاء مهمة جديدة في مادة ' + subject + '. تاريخ التسليم: ' + new Date(deadline).toLocaleDateString('ar'),
            type: 'info',
            recipients: 'all'
        });
    }

    showAlert('تم إنشاء المهمة بنجاح', 'success');
    bootstrap.Modal.getInstance(document.querySelector('.modal')).hide();
    loadAssignments();
}

function loadAssignments() {
    const assignments = JSON.parse(localStorage.getItem('assignments') || '[]');
    const tableBody = document.getElementById('assignments-table');
    if (!tableBody) return;

    tableBody.innerHTML = assignments.map(assignment => `
        <tr>
            <td>${assignment.title}</td>
            <td>${assignment.subject}</td>
            <td>${new Date(assignment.createdAt).toLocaleDateString('ar')}</td>
            <td>${new Date(assignment.deadline).toLocaleDateString('ar')}</td>
            <td>${assignment.submissions.length}/25</td>
            <td>${assignment.submissions.filter(s => s.graded).length}/${assignment.submissions.length}</td>
            <td><span class="badge bg-${assignment.status === 'active' ? 'success' : 'secondary'}">${assignment.status === 'active' ? 'نشطة' : 'مكتملة'}</span></td>
            <td>
                <button class="btn btn-sm btn-info" onclick="viewAssignment('${assignment.id}')" title="عرض المهمة">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-warning" onclick="editAssignment('${assignment.id}')" title="تعديل المهمة">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-success" onclick="viewSubmissions('${assignment.id}')" title="عرض الحلول">
                    <i class="fas fa-file-alt"></i>
                </button>
                <button class="btn btn-sm btn-primary" onclick="gradeSubmissions('${assignment.id}')" title="تصحيح">
                    <i class="fas fa-star"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteAssignment('${assignment.id}')" title="حذف المهمة">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function viewSubmissions(assignmentId) {
    const assignments = JSON.parse(localStorage.getItem('assignments') || '[]');
    const assignment = assignments.find(a => a.id === assignmentId);
    
    if (!assignment) return;

    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">حلول المهمة: ${assignment.title}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>اسم الطالب</th>
                                    <th>تاريخ التسليم</th>
                                    <th>نوع التسليم</th>
                                    <th>الدرجة</th>
                                    <th>الحالة</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${assignment.submissions.map(submission => `
                                    <tr>
                                        <td>${submission.studentName}</td>
                                        <td>${new Date(submission.submittedAt).toLocaleDateString('ar')}</td>
                                        <td>${submission.type === 'file' ? 'ملف' : submission.type === 'text' ? 'نص' : 'كلاهما'}</td>
                                        <td>
                                            ${submission.graded ? 
                                                `<span class="badge bg-success">${submission.grade}/${assignment.totalGrade}</span>` : 
                                                '<span class="badge bg-warning">غير مصحح</span>'
                                            }
                                        </td>
                                        <td>
                                            <span class="badge bg-${submission.graded ? 'success' : 'warning'}">
                                                ${submission.graded ? 'مصحح' : 'في انتظار التصحيح'}
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-info" onclick="viewSubmission('${submission.id}')" title="عرض الحل">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-sm btn-primary" onclick="gradeSubmission('${assignmentId}', '${submission.id}')" title="تصحيح">
                                                <i class="fas fa-star"></i>
                                            </button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
}

function gradeSubmission(assignmentId, submissionId) {
    const assignments = JSON.parse(localStorage.getItem('assignments') || '[]');
    const assignment = assignments.find(a => a.id === assignmentId);
    const submission = assignment.submissions.find(s => s.id === submissionId);
    
    if (!assignment || !submission) return;

    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تصحيح حل الطالب: ${submission.studentName}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="card mb-3">
                        <div class="card-header">
                            <h6>تفاصيل المهمة</h6>
                        </div>
                        <div class="card-body">
                            <p><strong>العنوان:</strong> ${assignment.title}</p>
                            <p><strong>الوصف:</strong> ${assignment.description}</p>
                            <p><strong>الدرجة الكاملة:</strong> ${assignment.totalGrade}</p>
                        </div>
                    </div>
                    
                    <div class="card mb-3">
                        <div class="card-header">
                            <h6>حل الطالب</h6>
                        </div>
                        <div class="card-body">
                            ${submission.textAnswer ? `<p><strong>الإجابة النصية:</strong></p><div class="border p-3 mb-3">${submission.textAnswer}</div>` : ''}
                            ${submission.fileName ? `<p><strong>الملف المرفق:</strong> ${submission.fileName}</p>` : ''}
                            <p><strong>تاريخ التسليم:</strong> ${new Date(submission.submittedAt).toLocaleString('ar')}</p>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h6>التصحيح والتقييم</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">الدرجة</label>
                                        <input type="number" class="form-control" id="grade-input" 
                                               min="0" max="${assignment.totalGrade}" 
                                               value="${submission.grade || ''}" required>
                                        <div class="form-text">من ${assignment.totalGrade}</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">التقدير</label>
                                        <select class="form-select" id="grade-letter">
                                            <option value="">اختر التقدير</option>
                                            <option value="A+">ممتاز مرتفع (A+)</option>
                                            <option value="A">ممتاز (A)</option>
                                            <option value="B+">جيد جداً مرتفع (B+)</option>
                                            <option value="B">جيد جداً (B)</option>
                                            <option value="C+">جيد مرتفع (C+)</option>
                                            <option value="C">جيد (C)</option>
                                            <option value="D">مقبول (D)</option>
                                            <option value="F">راسب (F)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">تعليقات الأستاذ</label>
                                <textarea class="form-control" id="feedback-input" rows="4" 
                                          placeholder="اكتب تعليقاتك وملاحظاتك على حل الطالب...">${submission.feedback || ''}</textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="button" class="btn btn-primary" onclick="saveGrade('${assignmentId}', '${submissionId}')">حفظ التصحيح</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
}

function saveGrade(assignmentId, submissionId) {
    const grade = document.getElementById('grade-input').value;
    const gradeLetter = document.getElementById('grade-letter').value;
    const feedback = document.getElementById('feedback-input').value;

    if (!grade) {
        showAlert('يرجى إدخال الدرجة', 'error');
        return;
    }

    let assignments = JSON.parse(localStorage.getItem('assignments') || '[]');
    const assignmentIndex = assignments.findIndex(a => a.id === assignmentId);
    const submissionIndex = assignments[assignmentIndex].submissions.findIndex(s => s.id === submissionId);

    assignments[assignmentIndex].submissions[submissionIndex].grade = parseInt(grade);
    assignments[assignmentIndex].submissions[submissionIndex].gradeLetter = gradeLetter;
    assignments[assignmentIndex].submissions[submissionIndex].feedback = feedback;
    assignments[assignmentIndex].submissions[submissionIndex].graded = true;
    assignments[assignmentIndex].submissions[submissionIndex].gradedAt = new Date().toISOString();

    localStorage.setItem('assignments', JSON.stringify(assignments));

    // Send notification to student
    const submission = assignments[assignmentIndex].submissions[submissionIndex];
    sendNotification({
        title: 'تم تصحيح مهمتك: ' + assignments[assignmentIndex].title,
        message: `تم تصحيح مهمتك وحصلت على درجة ${grade}/${assignments[assignmentIndex].totalGrade}`,
        type: 'success',
        recipients: 'specific',
        studentIds: [submission.studentId]
    });

    showAlert('تم حفظ التصحيح بنجاح', 'success');
    bootstrap.Modal.getInstance(document.querySelector('.modal')).hide();
    loadAssignments();
}

// File Management Functions
function uploadFile() {
    const title = document.getElementById('file-title').value;
    const description = document.getElementById('file-description').value;
    const subject = document.getElementById('file-subject').value;
    const category = document.getElementById('file-category').value;
    const fileInput = document.getElementById('file-input');
    const notifyStudents = document.getElementById('notify-students').checked;

    if (!title || !fileInput.files.length) {
        showAlert('يرجى إدخال عنوان الملف واختيار ملف للرفع', 'error');
        return;
    }

    const file = fileInput.files[0];
    const fileData = {
        id: 'file_' + Date.now(),
        title: title,
        description: description,
        subject: subject,
        category: category,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type,
        uploadedAt: new Date().toISOString(),
        uploadedBy: getCurrentUser().id,
        downloads: 0
    };

    // Save file data
    let files = JSON.parse(localStorage.getItem('courseFiles') || '[]');
    files.push(fileData);
    localStorage.setItem('courseFiles', JSON.stringify(files));

    // Send notification if requested
    if (notifyStudents) {
        sendNotification({
            title: 'ملف جديد: ' + title,
            message: 'تم رفع ملف جديد في ' + (subject || 'المقررات') + '. النوع: ' + getCategoryName(category),
            type: 'info',
            recipients: 'all'
        });
    }

    showAlert('تم رفع الملف بنجاح', 'success');
    document.getElementById('file-upload-form').reset();
    loadFiles();
}

function getCategoryName(category) {
    const categories = {
        'lecture': 'محاضرة',
        'assignment': 'مهمة',
        'exam': 'امتحان',
        'reference': 'مرجع',
        'announcement': 'إعلان',
        'other': 'أخرى'
    };
    return categories[category] || category;
}

function loadFiles() {
    const files = JSON.parse(localStorage.getItem('courseFiles') || '[]');
    const tableBody = document.getElementById('files-table');
    if (!tableBody) return;

    tableBody.innerHTML = files.map(file => `
        <tr>
            <td>
                <i class="fas fa-${getFileIcon(file.fileType)} me-2"></i>
                ${file.title}
            </td>
            <td>${getCategoryName(file.category)}</td>
            <td>${file.subject || 'عام'}</td>
            <td>${formatFileSize(file.fileSize)}</td>
            <td>${new Date(file.uploadedAt).toLocaleDateString('ar')}</td>
            <td><span class="badge bg-info">${file.downloads}</span></td>
            <td>
                <button class="btn btn-sm btn-success" onclick="downloadFile('${file.id}')" title="تحميل">
                    <i class="fas fa-download"></i>
                </button>
                <button class="btn btn-sm btn-info" onclick="viewFile('${file.id}')" title="عرض">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteFile('${file.id}')" title="حذف">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function getFileIcon(fileType) {
    if (fileType.includes('pdf')) return 'file-pdf';
    if (fileType.includes('word') || fileType.includes('document')) return 'file-word';
    if (fileType.includes('excel') || fileType.includes('spreadsheet')) return 'file-excel';
    if (fileType.includes('powerpoint') || fileType.includes('presentation')) return 'file-powerpoint';
    if (fileType.includes('image')) return 'file-image';
    if (fileType.includes('video')) return 'file-video';
    if (fileType.includes('audio')) return 'file-audio';
    return 'file';
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Exam Management Functions
function showCreateExamModal() {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إنشاء اختبار جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">عنوان الاختبار</label>
                                <input type="text" class="form-control" id="exam-title" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">المادة</label>
                                <select class="form-select" id="exam-subject" required>
                                    <option value="">اختر المادة</option>
                                    <option value="STAT301">الإحصاء المتقدم</option>
                                    <option value="DATA401">تحليل البيانات</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">مدة الاختبار (بالدقائق)</label>
                                <input type="number" class="form-control" id="exam-duration" min="5" max="180" value="60" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">الدرجة الكاملة</label>
                                <input type="number" class="form-control" id="exam-total-grade" min="1" max="100" value="20" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">عدد المحاولات المسموحة</label>
                                <input type="number" class="form-control" id="exam-attempts" min="1" max="5" value="1" required>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">تعليمات الاختبار</label>
                        <textarea class="form-control" id="exam-instructions" rows="3" placeholder="اكتب تعليمات الاختبار هنا..."></textarea>
                    </div>
                    
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6>الأسئلة</h6>
                            <div>
                                <button type="button" class="btn btn-sm btn-primary" onclick="addQuestion('multiple')">
                                    <i class="fas fa-plus"></i> اختيار من متعدد
                                </button>
                                <button type="button" class="btn btn-sm btn-success" onclick="addQuestion('truefalse')">
                                    <i class="fas fa-plus"></i> صح/خطأ
                                </button>
                                <button type="button" class="btn btn-sm btn-info" onclick="addQuestion('essay')">
                                    <i class="fas fa-plus"></i> مقالي
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="questions-container">
                                <!-- Questions will be added here -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="button" class="btn btn-primary" onclick="createExam()">إنشاء الاختبار</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
}

let questionCounter = 0;

function addQuestion(type) {
    questionCounter++;
    const container = document.getElementById('questions-container');
    
    let questionHTML = '';
    
    if (type === 'multiple') {
        questionHTML = `
            <div class="card mb-3" data-question-id="${questionCounter}">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span>سؤال ${questionCounter} - اختيار من متعدد</span>
                    <button type="button" class="btn btn-sm btn-danger" onclick="removeQuestion(${questionCounter})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">نص السؤال</label>
                        <textarea class="form-control question-text" rows="2" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">الخيارات</label>
                        <div class="options-container">
                            <div class="input-group mb-2">
                                <div class="input-group-text">
                                    <input class="form-check-input" type="radio" name="correct_${questionCounter}" value="0">
                                </div>
                                <input type="text" class="form-control option-text" placeholder="الخيار الأول">
                            </div>
                            <div class="input-group mb-2">
                                <div class="input-group-text">
                                    <input class="form-check-input" type="radio" name="correct_${questionCounter}" value="1">
                                </div>
                                <input type="text" class="form-control option-text" placeholder="الخيار الثاني">
                            </div>
                            <div class="input-group mb-2">
                                <div class="input-group-text">
                                    <input class="form-check-input" type="radio" name="correct_${questionCounter}" value="2">
                                </div>
                                <input type="text" class="form-control option-text" placeholder="الخيار الثالث">
                            </div>
                            <div class="input-group mb-2">
                                <div class="input-group-text">
                                    <input class="form-check-input" type="radio" name="correct_${questionCounter}" value="3">
                                </div>
                                <input type="text" class="form-control option-text" placeholder="الخيار الرابع">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">درجة السؤال</label>
                            <input type="number" class="form-control question-grade" min="1" max="10" value="1">
                        </div>
                    </div>
                </div>
            </div>
        `;
    } else if (type === 'truefalse') {
        questionHTML = `
            <div class="card mb-3" data-question-id="${questionCounter}">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span>سؤال ${questionCounter} - صح/خطأ</span>
                    <button type="button" class="btn btn-sm btn-danger" onclick="removeQuestion(${questionCounter})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">نص السؤال</label>
                        <textarea class="form-control question-text" rows="2" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">الإجابة الصحيحة</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="truefalse_${questionCounter}" value="true">
                                <label class="form-check-label">صح</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="truefalse_${questionCounter}" value="false">
                                <label class="form-check-label">خطأ</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">درجة السؤال</label>
                            <input type="number" class="form-control question-grade" min="1" max="10" value="1">
                        </div>
                    </div>
                </div>
            </div>
        `;
    } else if (type === 'essay') {
        questionHTML = `
            <div class="card mb-3" data-question-id="${questionCounter}">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span>سؤال ${questionCounter} - مقالي</span>
                    <button type="button" class="btn btn-sm btn-danger" onclick="removeQuestion(${questionCounter})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">نص السؤال</label>
                        <textarea class="form-control question-text" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">نموذج الإجابة (اختياري)</label>
                        <textarea class="form-control model-answer" rows="3" placeholder="اكتب نموذج الإجابة المتوقع..."></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">درجة السؤال</label>
                            <input type="number" class="form-control question-grade" min="1" max="20" value="5">
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    container.insertAdjacentHTML('beforeend', questionHTML);
}

function removeQuestion(questionId) {
    const questionElement = document.querySelector(`[data-question-id="${questionId}"]`);
    if (questionElement) {
        questionElement.remove();
    }
}

function createExam() {
    const title = document.getElementById('exam-title').value;
    const subject = document.getElementById('exam-subject').value;
    const duration = document.getElementById('exam-duration').value;
    const totalGrade = document.getElementById('exam-total-grade').value;
    const attempts = document.getElementById('exam-attempts').value;
    const instructions = document.getElementById('exam-instructions').value;

    if (!title || !subject || !duration) {
        showAlert('يرجى ملء جميع الحقول المطلوبة', 'error');
        return;
    }

    const questions = [];
    const questionCards = document.querySelectorAll('#questions-container .card');
    
    if (questionCards.length === 0) {
        showAlert('يرجى إضافة سؤال واحد على الأقل', 'error');
        return;
    }

    questionCards.forEach((card, index) => {
        const questionText = card.querySelector('.question-text').value;
        const questionGrade = card.querySelector('.question-grade').value;
        
        if (!questionText) {
            showAlert(`يرجى إدخال نص السؤال ${index + 1}`, 'error');
            return;
        }

        const question = {
            id: 'q_' + Date.now() + '_' + index,
            text: questionText,
            grade: parseInt(questionGrade),
            type: card.querySelector('.card-header span').textContent.includes('اختيار من متعدد') ? 'multiple' :
                  card.querySelector('.card-header span').textContent.includes('صح/خطأ') ? 'truefalse' : 'essay'
        };

        if (question.type === 'multiple') {
            const options = Array.from(card.querySelectorAll('.option-text')).map(input => input.value);
            const correctAnswer = card.querySelector(`input[name="correct_${card.dataset.questionId}"]:checked`)?.value;
            
            if (options.some(opt => !opt)) {
                showAlert(`يرجى ملء جميع خيارات السؤال ${index + 1}`, 'error');
                return;
            }
            
            if (correctAnswer === undefined) {
                showAlert(`يرجى اختيار الإجابة الصحيحة للسؤال ${index + 1}`, 'error');
                return;
            }
            
            question.options = options;
            question.correctAnswer = parseInt(correctAnswer);
        } else if (question.type === 'truefalse') {
            const correctAnswer = card.querySelector(`input[name="truefalse_${card.dataset.questionId}"]:checked`)?.value;
            
            if (!correctAnswer) {
                showAlert(`يرجى اختيار الإجابة الصحيحة للسؤال ${index + 1}`, 'error');
                return;
            }
            
            question.correctAnswer = correctAnswer === 'true';
        } else if (question.type === 'essay') {
            const modelAnswer = card.querySelector('.model-answer').value;
            question.modelAnswer = modelAnswer;
        }

        questions.push(question);
    });

    const exam = {
        id: 'exam_' + Date.now(),
        title: title,
        subject: subject,
        duration: parseInt(duration),
        totalGrade: parseInt(totalGrade),
        attempts: parseInt(attempts),
        instructions: instructions,
        questions: questions,
        createdAt: new Date().toISOString(),
        createdBy: getCurrentUser().id,
        submissions: [],
        status: 'active'
    };

    // Save exam
    let exams = JSON.parse(localStorage.getItem('exams') || '[]');
    exams.push(exam);
    localStorage.setItem('exams', JSON.stringify(exams));

    // Send notification to students
    sendNotification({
        title: 'اختبار جديد: ' + title,
        message: 'تم إنشاء اختبار جديد في مادة ' + subject + '. المدة: ' + duration + ' دقيقة',
        type: 'info',
        recipients: 'all'
    });

    showAlert('تم إنشاء الاختبار بنجاح', 'success');
    bootstrap.Modal.getInstance(document.querySelector('.modal')).hide();
    loadExams();
}

function loadExams() {
    const exams = JSON.parse(localStorage.getItem('exams') || '[]');
    const tableBody = document.getElementById('exams-table');
    if (!tableBody) return;

    tableBody.innerHTML = exams.map(exam => `
        <tr>
            <td>${exam.title}</td>
            <td>${exam.subject}</td>
            <td>${exam.questions.length} سؤال</td>
            <td>${exam.duration} دقيقة</td>
            <td>${new Date(exam.createdAt).toLocaleDateString('ar')}</td>
            <td><span class="badge bg-${exam.status === 'active' ? 'success' : 'secondary'}">${exam.status === 'active' ? 'نشط' : 'مكتمل'}</span></td>
            <td>
                <button class="btn btn-sm btn-info" onclick="viewExam('${exam.id}')" title="عرض الاختبار">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-warning" onclick="editExam('${exam.id}')" title="تعديل الاختبار">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-success" onclick="viewExamResults('${exam.id}')" title="النتائج">
                    <i class="fas fa-chart-line"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteExam('${exam.id}')" title="حذف الاختبار">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Initialize functions when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Load data for current page
    if (window.location.pathname.includes('professor-dashboard')) {
        loadAssignments();
        loadFiles();
        loadExams();
    }
    
    // Initialize IP tracking
    getUserIP();
});


// Fees Management Functions
function createFee() {
    const feeData = {
        studentId: document.getElementById('fee-student').value,
        type: document.getElementById('fee-type').value,
        amount: document.getElementById('fee-amount').value,
        dueDate: document.getElementById('fee-due-date').value,
        description: document.getElementById('fee-description').value,
        paymentCode: generatePaymentCode()
    };
    
    // Save fee to localStorage
    let fees = JSON.parse(localStorage.getItem('fees')) || [];
    feeData.id = 'FEE' + Date.now();
    feeData.status = 'pending';
    feeData.createdAt = new Date().toISOString();
    fees.push(feeData);
    localStorage.setItem('fees', JSON.stringify(fees));
    
    showAlert('تم إنشاء المصروفات بنجاح!', 'success');
    hideModal('create-fee-modal');
    loadFees();
}

function generatePaymentCode() {
    return 'PAY' + Math.random().toString(36).substr(2, 6).toUpperCase();
}

function payFee(feeId) {
    showModal('payment-modal');
    document.getElementById('payment-fee-id').value = feeId;
}

function confirmPayment(feeId) {
    let fees = JSON.parse(localStorage.getItem('fees')) || [];
    const feeIndex = fees.findIndex(f => f.id === feeId);
    if (feeIndex !== -1) {
        fees[feeIndex].status = 'paid';
        fees[feeIndex].paidAt = new Date().toISOString();
        localStorage.setItem('fees', JSON.stringify(fees));
        showAlert('تم تأكيد الدفع بنجاح!', 'success');
        loadFees();
    }
}

function copyPaymentCode(code) {
    navigator.clipboard.writeText(code).then(() => {
        showAlert('تم نسخ كود الدفع!', 'info');
    });
}

// Messages Functions
function showComposeMessageModal() {
    showModal('compose-message-modal');
}

function sendMessage(event) {
    event.preventDefault();
    
    const messageData = {
        id: 'MSG' + Date.now(),
        recipient: document.getElementById('message-recipient').value,
        subject: document.getElementById('message-subject').value,
        type: document.getElementById('message-type').value,
        content: document.getElementById('message-content').value,
        priority: document.getElementById('message-priority').value,
        attachments: getAttachments('message-attachments'),
        readReceipt: document.getElementById('request-read-receipt').checked,
        sentAt: new Date().toISOString(),
        status: 'sent',
        senderId: getCurrentUser().id
    };
    
    // Save message
    let messages = JSON.parse(localStorage.getItem('messages')) || [];
    messages.push(messageData);
    localStorage.setItem('messages', JSON.stringify(messages));
    
    showAlert('تم إرسال الرسالة بنجاح!', 'success');
    hideModal('compose-message-modal');
    document.querySelector('form').reset();
}

function getAttachments(inputId) {
    const files = document.getElementById(inputId).files;
    const attachments = [];
    for (let file of files) {
        attachments.push({
            name: file.name,
            size: file.size,
            type: file.type
        });
    }
    return attachments;
}

function openMessage(messageId) {
    showModal('view-message-modal');
    // Load message details
}

function replyToMessage() {
    hideModal('view-message-modal');
    showModal('reply-message-modal');
}

// Video Call Functions
function createMeeting() {
    const meetingData = {
        id: 'MEET' + Date.now(),
        title: document.getElementById('meeting-title').value,
        description: document.getElementById('meeting-description').value,
        date: document.getElementById('meeting-date').value,
        time: document.getElementById('meeting-time').value,
        duration: document.getElementById('meeting-duration').value,
        participants: getSelectedParticipants(),
        roomId: generateRoomId(),
        createdBy: getCurrentUser().id,
        createdAt: new Date().toISOString()
    };
    
    let meetings = JSON.parse(localStorage.getItem('meetings')) || [];
    meetings.push(meetingData);
    localStorage.setItem('meetings', JSON.stringify(meetings));
    
    showAlert('تم إنشاء الاجتماع بنجاح!', 'success');
    hideModal('create-meeting-modal');
    loadMeetings();
}

function generateRoomId() {
    return Math.random().toString(36).substr(2, 10).toUpperCase();
}

function joinMeeting(meetingId) {
    // Initialize WebRTC connection
    initializeVideoCall(meetingId);
    showModal('video-call-modal');
}

function initializeVideoCall(meetingId) {
    // WebRTC implementation would go here
    // For demo purposes, we'll show a placeholder
    document.getElementById('local-video').style.display = 'block';
    document.getElementById('remote-videos').innerHTML = '<div class="video-placeholder">انتظار المشاركين...</div>';
}

function toggleVideo() {
    const videoBtn = document.querySelector('[onclick="toggleVideo()"]');
    const isEnabled = videoBtn.classList.contains('btn-success');
    
    if (isEnabled) {
        videoBtn.classList.remove('btn-success');
        videoBtn.classList.add('btn-secondary');
        videoBtn.innerHTML = '<i class="fas fa-video-slash"></i>';
    } else {
        videoBtn.classList.remove('btn-secondary');
        videoBtn.classList.add('btn-success');
        videoBtn.innerHTML = '<i class="fas fa-video"></i>';
    }
}

function toggleAudio() {
    const audioBtn = document.querySelector('[onclick="toggleAudio()"]');
    const isEnabled = audioBtn.classList.contains('btn-success');
    
    if (isEnabled) {
        audioBtn.classList.remove('btn-success');
        audioBtn.classList.add('btn-secondary');
        audioBtn.innerHTML = '<i class="fas fa-microphone-slash"></i>';
    } else {
        audioBtn.classList.remove('btn-secondary');
        audioBtn.classList.add('btn-success');
        audioBtn.innerHTML = '<i class="fas fa-microphone"></i>';
    }
}

function shareScreen() {
    if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
        navigator.mediaDevices.getDisplayMedia({ video: true })
            .then(stream => {
                // Handle screen sharing
                showAlert('تم بدء مشاركة الشاشة', 'success');
            })
            .catch(err => {
                showAlert('فشل في مشاركة الشاشة', 'error');
            });
    } else {
        showAlert('مشاركة الشاشة غير مدعومة في هذا المتصفح', 'warning');
    }
}

function sendChatMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (message) {
        const chatMessages = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'chat-message';
        messageDiv.innerHTML = `
            <strong>${getCurrentUser().name}:</strong>
            <span>${message}</span>
            <small class="text-muted">${new Date().toLocaleTimeString()}</small>
        `;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        input.value = '';
    }
}

// File Upload Functions
function uploadFile() {
    const fileData = {
        id: 'FILE' + Date.now(),
        title: document.getElementById('file-title').value,
        description: document.getElementById('file-description').value,
        category: document.getElementById('file-category').value,
        file: document.getElementById('file-upload').files[0],
        uploadedBy: getCurrentUser().id,
        uploadedAt: new Date().toISOString(),
        visibility: document.getElementById('file-visibility').value
    };
    
    let files = JSON.parse(localStorage.getItem('files')) || [];
    files.push(fileData);
    localStorage.setItem('files', JSON.stringify(files));
    
    showAlert('تم رفع الملف بنجاح!', 'success');
    hideModal('upload-file-modal');
    loadFiles();
}

// Exam Functions
function createExam() {
    const examData = {
        id: 'EXAM' + Date.now(),
        title: document.getElementById('exam-title').value,
        description: document.getElementById('exam-description').value,
        duration: document.getElementById('exam-duration').value,
        startDate: document.getElementById('exam-start-date').value,
        endDate: document.getElementById('exam-end-date').value,
        questions: getExamQuestions(),
        createdBy: getCurrentUser().id,
        createdAt: new Date().toISOString()
    };
    
    let exams = JSON.parse(localStorage.getItem('exams')) || [];
    exams.push(examData);
    localStorage.setItem('exams', JSON.stringify(exams));
    
    showAlert('تم إنشاء الاختبار بنجاح!', 'success');
    hideModal('create-exam-modal');
    loadExams();
}

function getExamQuestions() {
    // This would collect questions from the exam creation form
    return [];
}

// Assignment Functions
function createAssignment() {
    const assignmentData = {
        id: 'ASSIGN' + Date.now(),
        title: document.getElementById('assignment-title').value,
        description: document.getElementById('assignment-description').value,
        dueDate: document.getElementById('assignment-due-date').value,
        maxGrade: document.getElementById('assignment-max-grade').value,
        instructions: document.getElementById('assignment-instructions').value,
        attachments: getAttachments('assignment-attachments'),
        createdBy: getCurrentUser().id,
        createdAt: new Date().toISOString()
    };
    
    let assignments = JSON.parse(localStorage.getItem('assignments')) || [];
    assignments.push(assignmentData);
    localStorage.setItem('assignments', JSON.stringify(assignments));
    
    showAlert('تم إنشاء المهمة بنجاح!', 'success');
    hideModal('create-assignment-modal');
    loadAssignments();
}

function submitAssignment(assignmentId) {
    const submissionData = {
        id: 'SUB' + Date.now(),
        assignmentId: assignmentId,
        studentId: getCurrentUser().id,
        content: document.getElementById('submission-content').value,
        attachments: getAttachments('submission-attachments'),
        submittedAt: new Date().toISOString(),
        status: 'submitted'
    };
    
    let submissions = JSON.parse(localStorage.getItem('submissions')) || [];
    submissions.push(submissionData);
    localStorage.setItem('submissions', JSON.stringify(submissions));
    
    showAlert('تم تسليم المهمة بنجاح!', 'success');
    hideModal('submit-assignment-modal');
}

function gradeAssignment(submissionId, grade, feedback) {
    let submissions = JSON.parse(localStorage.getItem('submissions')) || [];
    const submissionIndex = submissions.findIndex(s => s.id === submissionId);
    
    if (submissionIndex !== -1) {
        submissions[submissionIndex].grade = grade;
        submissions[submissionIndex].feedback = feedback;
        submissions[submissionIndex].gradedAt = new Date().toISOString();
        submissions[submissionIndex].status = 'graded';
        localStorage.setItem('submissions', JSON.stringify(submissions));
        
        showAlert('تم تقييم المهمة بنجاح!', 'success');
    }
}

// Enhanced IP tracking with more details
async function getDetailedUserInfo() {
    try {
        // Get basic browser info
        const browserInfo = {
            userAgent: navigator.userAgent,
            language: navigator.language,
            platform: navigator.platform,
            cookieEnabled: navigator.cookieEnabled,
            onLine: navigator.onLine,
            screenResolution: `${screen.width}x${screen.height}`,
            colorDepth: screen.colorDepth,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        };

        // Try to get IP and location info
        let ipInfo = {};
        try {
            const response = await fetch('https://ipapi.co/json/');
            ipInfo = await response.json();
        } catch (error) {
            // Fallback IP detection
            ipInfo = {
                ip: 'Unknown',
                city: 'Unknown',
                country: 'Unknown',
                org: 'Unknown'
            };
        }

        return {
            ...browserInfo,
            ...ipInfo,
            timestamp: new Date().toISOString()
        };
    } catch (error) {
        return {
            ip: 'Unknown',
            userAgent: navigator.userAgent,
            timestamp: new Date().toISOString()
        };
    }
}

// Update login function to include detailed tracking
async function enhancedLogin(email, password, userType) {
    const userInfo = await getDetailedUserInfo();
    
    // Save login attempt with detailed info
    let loginLogs = JSON.parse(localStorage.getItem('loginLogs')) || [];
    loginLogs.push({
        email: email,
        userType: userType,
        success: true, // This would be determined by actual login logic
        userInfo: userInfo,
        sessionId: 'SESSION' + Date.now(),
        loginTime: new Date().toISOString()
    });
    localStorage.setItem('loginLogs', JSON.stringify(loginLogs));
    
    // Continue with normal login process
    return login(email, password, userType);
}

// Initialize enhanced features
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all enhanced features
    initializeNotifications();
    loadUserData();
    setupEventListeners();
});

function initializeNotifications() {
    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
}

function setupEventListeners() {
    // Setup file input change listeners for preview
    document.addEventListener('change', function(e) {
        if (e.target.type === 'file') {
            previewAttachments(e.target);
        }
    });
    
    // Setup chat input enter key
    document.addEventListener('keypress', function(e) {
        if (e.target.id === 'chat-input' && e.key === 'Enter') {
            sendChatMessage();
        }
    });
}

function previewAttachments(input) {
    const previewContainer = input.parentNode.querySelector('[id$="-preview"]');
    if (previewContainer && input.files.length > 0) {
        previewContainer.innerHTML = '';
        for (let file of input.files) {
            const fileDiv = document.createElement('div');
            fileDiv.className = 'attachment-preview';
            fileDiv.innerHTML = `
                <i class="fas fa-file"></i>
                <span>${file.name}</span>
                <small>(${(file.size / 1024).toFixed(1)} KB)</small>
            `;
            previewContainer.appendChild(fileDiv);
        }
    }
}

